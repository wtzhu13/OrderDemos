from tkinter import *  
from LoginPage import *  
  
root = Tk()  
root.title('车辆管理系统_by vision')
LoginPage(root)  
root.mainloop()  
